

print 5 / 0

print "but life goes on"

